package com.example.barcodeqrapp;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureEnable extends CaptureActivity {

}
