import qrcode
import re
import base64
import json
import cv2
import pyzbar.pyzbar as pyzbar
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import padding, utils
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

#This file acts as the validator

# Load the public key from file
with open("public_key.pem", "rb") as f:
    public_key = serialization.load_pem_public_key(f.read(), backend=default_backend())

# Load the QR code image and decode it
img = cv2.imread('youtube.png')
# Decode the QR code
decoded_objs = pyzbar.decode(img)
#extract to a string
result = ''
for obj in decoded_objs:
    result += obj.data.decode('utf-8')

message = result.encode('utf-8')

# Extract the domain name using regular expressions
domain_name = re.search('([\w-]+\.[\w-]+)+', result).group()
qr_data = message.decode()[len(domain_name):]


# Parse the JSON data to extract the certificate and signature
try:
    qr_data_dict = json.loads(qr_data)
except :
    print("No certificate attached to this QR code.")
certificate_data = qr_data_dict["data"]
certificate_data_encoded = json.dumps(certificate_data).encode("utf-8")
certificate_signature = base64.b64decode(qr_data_dict["signature"].encode("utf-8"))

# Verify the signature using the public key
try:
    public_key.verify(
        certificate_signature,
        certificate_data_encoded,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    print("Certificate is valid.")
except InvalidSignature:
    print("Certificate is invalid.")