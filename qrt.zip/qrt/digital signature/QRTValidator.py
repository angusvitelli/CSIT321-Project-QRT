import qrcode
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
import cv2
import pyzbar.pyzbar as pyzbar
from PIL import Image

# Load the digital signature from the binary file
with open("digital_signature.bin", "rb") as f:
    signature = f.read()

# Load the public key from the PEM file
with open("public_key.pem", "rb") as f:
    public_key_bytes = f.read()
    public_key = serialization.load_pem_public_key(
        public_key_bytes,
        backend=default_backend()
    )

# Verify the digital signature using the public key

# Load the image
img = cv2.imread('qrcode.png')
# Decode the QR code
decoded_objs = pyzbar.decode(img)
#extract to a string
result = ''
for obj in decoded_objs:
    result += obj.data.decode('utf-8')

message = result.encode('utf-8')

# Looks for signature/tiny cert in QR code
try:
    public_key.verify(
        signature,
        message,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    print("Digital signature is valid.")
except InvalidSignature:
    print("Digital signature is invalid.")
