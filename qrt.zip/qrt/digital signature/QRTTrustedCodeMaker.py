import qrcode
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from PIL import Image

#create qr code
data = input("INPUT TRUSTED QR URL")
img = qrcode.make(data)
img.save("qrcode.png")
print("Test Done.")

# Load the private key from the PEM file
with open("private_key.pem", "rb") as f:
    private_key_bytes = f.read()
    private_key = serialization.load_pem_private_key(
        private_key_bytes,
        password=None,
        backend=default_backend()
    )

# Sign the data with the private key
message = data.encode()
signature = private_key.sign(
    message,
    padding.PSS(
        mgf=padding.MGF1(hashes.SHA256()),
        salt_length=padding.PSS.MAX_LENGTH
    ),
    hashes.SHA256()
)

# Embed the digital signature as metadata in the image
img = Image.open("qrcode.png")
img.info["signature"] = signature
img.save("qrcode.png")