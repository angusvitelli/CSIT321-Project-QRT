import qrcode
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from PIL import Image

# This file makes qr codes using the private key.

with open("my_certificate.json","rb") as f:
    certificate = f.read()

# Generate a QR code image from the JSON string
qr = qrcode.QRCode(
    version=None,
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4
)
qr.add_data("google.com")
qr.add_data(certificate)
qr.make(fit=True)

# Get the QR code image as a PIL image object
img = qr.make_image(fill_color="black", back_color="white")

# Save the image to a file
img.save("QRTgoogle.png")