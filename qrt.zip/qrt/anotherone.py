import qrcode
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
import base64
import json
from PIL import Image

#This file creates the keys and certificates we aim to use.

# Generate a private/public key pair
private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=1024,
    backend=default_backend()
)
public_key = private_key.public_key()

# Serialize the private key to PEM format
private_key_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption(),
)

# Generate an ID for the certificate
certificate_id = "QRT"

# Define the expiry date for the certificate
expiry_date = datetime.utcnow() + timedelta(days=365)
expiry_date_str = expiry_date.isoformat()
private_key_str = base64.b64encode(private_key_pem).decode("utf-8")

# Build the certificate as a dictionary containing the essential fields
certificate_data = {
    "id": certificate_id,
    "expiry_date": expiry_date_str,
}

# Serialize the JSON object to a JSON string
certificate_data_json = json.dumps(certificate_data)

# Sign the JSON string using the private key
signature = private_key.sign(
    certificate_data_json.encode("utf-8"),
    padding.PSS(
        mgf=padding.MGF1(hashes.SHA256()),
        salt_length=padding.PSS.MAX_LENGTH
    ),
    hashes.SHA256()
)

# Convert the signature to a base64-encoded string
signature_base64 = base64.b64encode(signature).decode("utf-8")

# Create a JSON object containing the certificate data and signature
certificate = {
    "data": certificate_data,
    "signature": signature_base64
}

# Serialize the JSON object to a JSON string
certificate_json = json.dumps(certificate)

# Save the certificate to a file
with open("my_certificate.json", "w") as f:
    json.dump(certificate, f)

# Export public key
with open("public_key.pem", "wb") as f:
    f.write(public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    ))

# Export the private key to a PEM file
with open("private_key.pem", "wb") as f:
    f.write(private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    ))

