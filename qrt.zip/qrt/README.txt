Hey guys, my name is Angus and this is my silly little program.

At first I tried using digital signatures to achieve a model in which I could create QR codes, 
but then I realised it would be way too difficult to decode whether or not the digital signature
had been used because everytime the url changed for a new qr code, there would need to be a new signature.

I then created tiny certifcates stored in the "my_certificate" json along with the "public_key" and "private_key" 
stored in respective files. This is the function of anotherone.py

anotheroneqrt is the qr code creator and embeds the qr code metadata with the tiny certificate

anotheronevalidator is what we use to ensure that the qr codes have a certificate that is valid.
The code will check for an object and if the object is found, the public key will be compared against the private key
to reveal the validity of the source.

I believe this can be used to speed up the user experience of the QRT application.